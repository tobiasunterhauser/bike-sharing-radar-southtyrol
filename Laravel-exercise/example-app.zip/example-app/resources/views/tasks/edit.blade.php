@extends('tasks.layout')
@section('content')
    <form action="{{ route('tasks.update',$task->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <br>
            <p><b>Name:</b></p>
            <input type="text" value="{{ $task->name }}" name="name" placeholder="Name">
        </div>
        <div>
            <br><br>
            <p><b>Detail:</b></p>
            <input type="text" value="{{ $task->detail }}" name="detail" placeholder="Detail" style="height: 100px; width: 300px;">
        </div>
        <br>
        <button type="submit">Submit</button>
    </form>
@endsection