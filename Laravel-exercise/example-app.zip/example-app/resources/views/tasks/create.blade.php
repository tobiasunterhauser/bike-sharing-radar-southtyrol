@extends('tasks.layout')
@section('content')
    <form action="{{ route('tasks.store') }}" method="POST">
        @csrf
        <div>
            <br>
            <p><b>Name:</b></p>
            <input type="text" name="name" placeholder="Name">
        </div>
        <div>
            <br><br>
            <p><b>Detail:</b></p>
            <input type="text" name="detail" placeholder="Detail" style="height: 100px; width: 300px;">
        </div>
        <br>
        <button type="submit">Submit</button>
    </form>
@endsection