@extends('tasks.layout')
@section('content')
    <div>
        <br>
        <h3 style="text-align: center;">Lab 09</h3>
        <br>
        <a style="text-decoration: none; color:darkblue;" href="{{route('tasks.create')}}"><b><u>Create new task</u></b></a>
        <br><br>
    </div>
    @if ($message = Session::get('success'))
        <div>
            <p style="color: green;"><b>{{ $message }}</b></p>
        </div>
    @endif
    <table border="1">
        <tr>
            <th width="50px" style="padding: 5;">Nr.</th>
            <th width="100px" style="padding: 5;">Name</th>
            <th width="200px" style="padding: 5;">Details</th>
            <th width="200px" style="padding: 5;">Actions</th>
        </tr>
        @foreach ($tasks as $task)
        <tr>
            <td style="padding: 5;">{{ ++$i }}</td>
            <td style="padding: 5;">{{ $task->name }}</td>
            <td style="padding: 5;">{{ $task->detail }}</td>
            <td style="padding-top: 5; padding-left:10;">
                <form action="{{ route('tasks.destroy',$task->id) }}" method="POST">
                    <a style="padding-right: 5;" href="{{route('tasks.show',$task->id)}}">Show</a>
                    <a style="padding-right: 5;" href="{{route('tasks.edit',$task->id)}}">Edit</a>
                    @csrf
                    @method('DELETE')
                    <button>Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
@endsection