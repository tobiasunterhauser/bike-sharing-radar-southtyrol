
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <br>
            <p><b>Name:</b></p>
            <input type="text" name="name" placeholder="Name">
        </div>
        <div>
            <br><br>
            <p><b>Detail:</b></p>
            <input type="text" name="detail" placeholder="Detail" style="height: 100px; width: 300px;">
        </div>
        <br>
        <button type="submit">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\example-app\resources\views/tasks/create.blade.php ENDPATH**/ ?>