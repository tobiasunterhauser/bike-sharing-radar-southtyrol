<html>
    <head>
        <title>Tasks</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css">
    </head>
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH C:\Program Files\xampp\htdocs\example-app\resources\views/tasks/layout.blade.php ENDPATH**/ ?>