
<?php $__env->startSection('content'); ?>
    <div>
        <br>
        <h3 style="text-align: center;">Lab 09</h3>
        <br>
        <a style="text-decoration: none; color:darkblue;" href="<?php echo e(route('tasks.create')); ?>"><b><u>Create new task</u></b></a>
        <br><br>
    </div>
    <?php if($message = Session::get('success')): ?>
        <div>
            <p style="color: green;"><b><?php echo e($message); ?></b></p>
        </div>
    <?php endif; ?>
    <table border="1">
        <tr>
            <th width="50px" style="padding: 5;">Nr.</th>
            <th width="100px" style="padding: 5;">Name</th>
            <th width="200px" style="padding: 5;">Details</th>
            <th width="200px" style="padding: 5;">Actions</th>
        </tr>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="padding: 5;"><?php echo e(++$i); ?></td>
            <td style="padding: 5;"><?php echo e($task->name); ?></td>
            <td style="padding: 5;"><?php echo e($task->detail); ?></td>
            <td style="padding-top: 5; padding-left:10;">
                <form action="<?php echo e(route('tasks.destroy',$task->id)); ?>" method="POST">
                    <a style="padding-right: 5;" href="<?php echo e(route('tasks.show',$task->id)); ?>">Show</a>
                    <a style="padding-right: 5;" href="<?php echo e(route('tasks.edit',$task->id)); ?>">Edit</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button>Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\example-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>