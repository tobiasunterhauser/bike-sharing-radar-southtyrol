
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('tasks.update',$task->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <br>
            <p><b>Name:</b></p>
            <input type="text" value="<?php echo e($task->name); ?>" name="name" placeholder="Name">
        </div>
        <div>
            <br><br>
            <p><b>Detail:</b></p>
            <input type="text" value="<?php echo e($task->detail); ?>" name="detail" placeholder="Detail" style="height: 100px; width: 300px;">
        </div>
        <br>
        <button type="submit">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\example-app\resources\views/tasks/edit.blade.php ENDPATH**/ ?>