<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Name:</strong>
            <?php echo e($task->name); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="from-group">
            <strong>Details:</strong>
            <?php echo e($task->detail); ?>

        </div>
    </div>
</div><?php /**PATH C:\Program Files\xampp\htdocs\example-app\resources\views/tasks/show.blade.php ENDPATH**/ ?>